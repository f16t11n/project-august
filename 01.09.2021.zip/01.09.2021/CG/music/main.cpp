#include<isotream>
#include<windows.h>
#include<mmsystem.h>

using namespace std;

int main(){


            PlaySound(TEXT("1.wav"), NULL, SND_ASYNC);
}
