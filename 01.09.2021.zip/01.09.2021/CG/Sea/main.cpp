#include<windows.h>
#include<iostream>
#include<GL/glut.h>
#include<GL/glu.h>
#include<GL/gl.h>
#include<math.h>
#define PI 3.14159265358979323846

using namespace std;

// canvas size
int xCanvas = 1366;
int yCanvas = 768;

void display();
void circle(float,float,float);
void sun();
void area();
void sea();
void hill(int x, int y);
void ship();
void cloud(int r, int g, int b);
void init();
void timer(int);


int main(int argc, char **argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

    glutInitWindowPosition(0,0);
    glutInitWindowSize(xCanvas,yCanvas);

    glutCreateWindow("Animation");

    glutDisplayFunc(display);
    glutTimerFunc(0,timer,0);
    init();

    glutMainLoop();
}

void display(){
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    sun();
    area();

    //cloud
    glPushMatrix();
    glTranslatef(300,83,0);
    glColor3ub(150,50,190);
    cloud(255,255,255);
    glPopMatrix();

    //cloud 2
    glPushMatrix();
    glTranslatef(-300,0,0);
    glColor3ub(150,50,190);
    cloud(255,255,255);
    glPopMatrix();

    //cloud 3
    glPushMatrix();
    glTranslatef(0,110,0);
    glColor3ub(150,50,190);
    cloud(255,255,255);
    glPopMatrix();

    //hill
    glPushMatrix();
    glTranslatef(-500,83,0);
    glColor3ub(200,120,0);
    hill(0,0);
    glPopMatrix();

    //hill 2
    glPushMatrix();
    glTranslatef(-300,83,0);
    glColor3ub(20,120,10);
    hill(-50,-50);
    glPopMatrix();


    //hill 3
    glPushMatrix();
    glTranslatef(-100,83,0);
    glColor3ub(220,10,100);
    hill(150,0);
    glPopMatrix();


    //hill 4
    glPushMatrix();
    glTranslatef(300,83,0);
    glColor3ub(150,50,190);
    hill(50,-50);
    glPopMatrix();

    sea();
    ship();
    glutSwapBuffers();
}


void init(){
    glClearColor(0,1,1,0.1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-xCanvas/2,xCanvas/2,-yCanvas/2,yCanvas/2);
    glMatrixMode(GL_MODELVIEW);
}

void circle(float x, float y, float r){
    float theta;
    glBegin(GL_POLYGON);
    for(int i=0;i<360;i++){
        theta=i*3.142/180;
        glVertex2f(x+r*cos(theta),y+r*sin(theta));
    }
    glEnd();
}
void sun(){

     glColor3ub(232, 211, 53);
     circle(-100,100,50);
}
void cloud(int cr, int cg,int cb){
     glColor3ub(cr, cg, cb);
     circle(-100,200,50);
     circle(-50,190,40);
     circle(-140,190,40);
}

void area(){
    glBegin(GL_QUADS);
    glColor3ub(48,160,235);
    glVertex2d(-683,-183);
    glColor3ub(128,128,128);
    glVertex2d(683,-183);
    glVertex2d(683,-383);
    glVertex2d(-683,-383);
    glEnd();
}

void hill(int x, int y){
    glBegin(GL_TRIANGLES);
    glVertex3f(0+x,120+y,0);
    glVertex3f(200+x,0+y,0);
    glVertex3f(-200+x,0+y,0);
    glEnd();
}

void sea(){

    glBegin(GL_QUADS);
    glColor3ub(48,160,235);
    glVertex2d(-683,-183);
    glColor3ub(128,128,128);
    glVertex2d(683,-183);
    glColor3ub(48,160,235);
    glVertex2d(683,83);
    glVertex2d(-683,83);
    glEnd();
}

int x_position = xCanvas/2;

void ship(){
    glBegin(GL_QUADS);
    glColor3ub(40, 112, 186);
    glVertex2d(x_position,80);
    glVertex2d(x_position+400,60);
    glVertex2d(x_position+350,0);
    glVertex2d(x_position+50,0);
    glEnd();


    //pipe
    glPushMatrix();
    glTranslatef(x_position+150,150,0);
    glBegin(GL_QUADS);
    glColor3ub(5, 5, 5);
    glVertex2d(0,70);
    glVertex2d(40,70);
    glVertex2d(40,0);
    glVertex2d(0,0);
    glEnd();
    glPopMatrix();

    //pipe
    glPushMatrix();
    glTranslatef(x_position+250,140,0);
    glBegin(GL_QUADS);
    glColor3ub(5, 5, 5);
    glVertex2d(0,65);
    glVertex2d(40,65);
    glVertex2d(40,0);
    glVertex2d(0,0);
    glEnd();
    glPopMatrix();

    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2d(x_position+80,160);
    glVertex2d(x_position+380,140);
    glVertex2d(x_position+390,92);
    glVertex2d(x_position+20,105);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2d(x_position-10,110);
    glVertex2d(x_position+420,90);
    glVertex2d(x_position+400,60);
    glVertex2d(x_position+0,80);
    glEnd();


}
void timer(int){
    glutPostRedisplay();
    glutTimerFunc(1000/60,timer,0);
    cout<<x_position<<endl;
    if(x_position<=-xCanvas/2-600){
        x_position=xCanvas/2+400;
    }else{
        x_position -= 5;
    }

}
