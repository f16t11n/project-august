#include<Windows.h>
#include <MMSystem.h>
#include<GL/glut.h>
#include<GL/glu.h>
#include<GL/gl.h>
#include<math.h>
#include <iostream>
using namespace std;
#define PI 3.14159265358979323846



float x_position=-950.0;
float y_position=-500.0;
float x_car1 = x_position;
float x_bus1 = -(x_position)-150;
float y_bus1 = y_position+100;
int notice = 0;
char sound[2] = "1";
int very_slow=2;
int slow=4;
int fast=6;

// car running
int l_red = 0;
int l_green = 1;

int red = 255;
int green = 255;
int blue = 255;


void init(){
    glClearColor(0,1,1,.51);  // background - RGBA
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-950,950,-500,500);
    glMatrixMode(GL_MODELVIEW);
}

void circle(float x, float y, float r){
    float theta;
    glBegin(GL_POLYGON);
    for(int i=0;i<360;i++){
        theta=i*3.142/180;
        glVertex2f(x+r*cos(theta),y+r*sin(theta));
    }
    glEnd();
}

void road(int x, int y){
    glBegin(GL_QUADS);
    glVertex2f(0,0);
    glVertex2f(x,0);
    glVertex2f(x,y);
    glVertex2f(0,y);
    glEnd();
}
void car(float cr,float cg, float cb, float wr, float wg, float wb, float whr,float whg,float whb){



    glColor3ub(cr,cg,cb);
    //top part
    glBegin(GL_POLYGON);
    glVertex2f(20,0);
    glVertex2f(60,20);
    glVertex2f(60,20);
    glVertex2f(110,20);
    glVertex2f(140,0);
    glEnd();
    //body
    glBegin(GL_POLYGON);
    glVertex2f(0,0);
    glVertex2f(170,0);
    glVertex2f(170,-30);
    glVertex2f(0,-30);
    glEnd();

    //window part
    glColor3ub(wr,wg,wb);
    glBegin(GL_POLYGON);
    glVertex2f(30,0);
    glVertex2f(60,15);
    glVertex2f(75,15);
    glVertex2f(75,0);
    glEnd();

    //window part

    glColor3f(wr,wg,wb);
    glBegin(GL_POLYGON);
    glVertex2f(90, 15);
    glVertex2f(105,15);
    glVertex2f(135,0);
    glVertex2f(90,0);
    glEnd();

    glColor3ub(whr,whg,whb);
    circle(30,-30,10);
    circle(120,-30,10);


}

void window(int whr, int whg, int whb){

    glColor3ub(whr,whg,whb);
    glBegin(GL_QUADS);
    glVertex2f(30,45);
    glVertex2f(50,45);
    glVertex2f(50,35);
    glVertex2f(30,35);
    glEnd();

}

void bus(float br,float bg, float bb, float wr, float wg, float wb, float whr,float whg,float whb){


    //Body
    glColor3ub(br,bg,bb);
    glBegin(GL_POLYGON);
    glVertex2f(0,20);
    glVertex2f(10,60);
    glVertex2f(180,60);
    glVertex2f(180,0);
    glVertex2f(0,0);
    glEnd();

    //wheel

    glColor3ub(whr,whg,whb);
    circle(50,0,10);
    circle(150,0,10);

    //Door
    glColor3ub(whr,whg,whb);
    glBegin(GL_QUADS);
    glVertex2f(15,25);
    glVertex2f(25,25);
    glVertex2f(25,0);
    glVertex2f(15,0);
    glEnd();

    //window

    window(255,255,255);
    glTranslatef(35,0,0);
    window(255,255,255);
    glTranslatef(35,0,0);
    window(255,255,255);
    glTranslatef(35,0,0);
    window(255,255,255);

}

void devider(){

    glColor3ub(255,255,255);
    glLineWidth(5);
    glBegin(GL_LINES);
    for(int i=0;i<=700;i=i+250){
        glVertex2f(i,-50);
        glVertex2f(i+150,-50);
    }
    glEnd();
}
void devider2(){

    glColor3ub(255,255,255);
    glLineWidth(5);
    glBegin(GL_LINES);
    for(int i=200;i<=400;i=i+200){
        glVertex2f(0,i);
        glVertex2f(0,i+100);
    }
    glEnd();
}

void traffic(int r, int g, int b,int r1,int g1, int b1){

    glPushMatrix();
    glBegin(GL_LINES);
    glColor3ub(0,120,151);
    glVertex2f(0,-105);
    glVertex2f(100,0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(100,0,0);
    glColor3ub(255,255,220);
    glBegin(GL_QUADS);
    glVertex2f(-60,0);
    glVertex2f(0,0);
    glVertex2f(-60,-60);
    glVertex2f(-120,-60);
    glEnd();
    glPopMatrix();

    //red
    glPushMatrix();
    glColor3ub(r,g,b);
    circle(50,-20,12);
    glPopMatrix();
    //green
    glPushMatrix();
    glColor3ub(r1,g1,b1);
    circle(30,-40,12);
    glPopMatrix();
}


void building_window(int h, int w, int wr, int wg, int wb){

    glColor3ub(wr ,wg, wb);
    glBegin(GL_QUADS);
    glVertex2f( 15,  300);
    glVertex2f( 25+w,  300);
    glVertex2f( 25+w,  310+h);
    glVertex2f( 15,  310+h);
    glEnd();
}

void building1(){

    glColor3ub(137 ,113, 95);
    glBegin(GL_QUADS);
    glVertex2f( 0,  290);
    glVertex2f( 0,  360);
    glVertex2f( 90,  360);
    glVertex2f( 90,  290);
    glEnd();


    glBegin(GL_QUADS);
    glVertex2f( 5,  360);
    glVertex2f( 5,  430);
    glVertex2f( 85,  430);
    glVertex2f( 85,  360);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f( 10,  430);
    glVertex2f( 10,  500);
    glVertex2f( 80,  500);
    glVertex2f( 80,  430);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex2f( 30,  500);
    glVertex2f( 50,  550);
    glVertex2f( 70,  500);
    glEnd();

    glLineWidth(4);
    glColor3ub(0 ,0, 0);
    glBegin(GL_LINES);
    glVertex2f( 0,  360);
    glVertex2f( 90,  360);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f( 5,  430);
    glVertex2f( 85,  430);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f( 10,  500);
    glVertex2f( 80,  500);
    glEnd();

    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(0,25,0);

    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);

    glTranslatef(0,50,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);



    building_window(0,0,255,255,255);
    glTranslatef(-15,15,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);



    glTranslatef(0,70,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(15,0,0);
    building_window(0,0,255,255,255);


    building_window(0,0,255,255,255);
    glTranslatef(0,15,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
    glTranslatef(-15,0,0);
    building_window(0,0,255,255,255);
}


// building 2

void building2(){

    glColor3ub(139 ,112 ,96);
    glBegin(GL_QUADS);
    glVertex2f( 0,  100);
    glVertex2f( 0,  280);
    glVertex2f( 130,  280);
    glVertex2f( 130,  100);
    glEnd();


    glLineWidth(4);
    glColor3ub(195, 173, 126);
    glBegin(GL_LINES);
    glVertex2f( 0,  160);
    glVertex2f( 130,  160);
    glVertex2f( 0,  220);
    glVertex2f( 130,  220);
    glVertex2f( 65,  100);
    glVertex2f( 65,  280);
    glEnd();

    glTranslatef(0,-180,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(15,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(50,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(15,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(0,60,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(-15,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(-50,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(-15,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(0,60,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(15,0,0);
    building_window(15,0,137, 186 ,226);
    building_window(15,0,137, 186 ,226);
    glTranslatef(50,0,0);
    building_window(15,0,137, 186 ,226);
    glTranslatef(15,0,0);
    building_window(15,0,137, 186 ,226);
}

//bus 2
void bus2(){
    glColor3ub(139 ,112 ,96);

    //front
    glBegin(GL_QUADS);
    glVertex2f( 30,  -300);
    glVertex2f( 110,  -300);
    glVertex2f( 110,  -270);
    glVertex2f( 30,  -270);
    glEnd();

    //Head
    glBegin(GL_QUADS);
    glVertex2f( 20,  -300);
    glVertex2f( 120,  -300);
    glVertex2f( 120,  -450);
    glVertex2f( 20,  -450);
    glEnd();

}

void accident_notice()
{
    glColor3ub(255,0,0);
    glBegin(GL_QUADS);
    glVertex2d(x_position+400,0);
    glVertex2d(-x_position-400,0);
    glVertex2d(-x_position-400,400);
    glVertex2d(x_position+400,400);
    glEnd();
}

void timer(int){
    glutPostRedisplay();
    glutTimerFunc(1000/60,timer,0);
    if(x_car1>=1250){
        x_car1=x_position;
    }
    if(x_bus1<= -1250){
        x_bus1=-x_position;
    }
    if(l_red==1 && x_car1 <=-335 && x_car1>= -350){
        x_car1 = -335;
    }else{
        x_car1+=slow;
    }
    if(l_red==1 && x_bus1 <=168 && x_bus1 >= 158){
        x_bus1 = 158;
    }else{
        x_bus1-=very_slow;
    }
    if((y_bus1>158 && y_bus1 <320) && (x_bus1<138 && x_bus1>8)){
        x_bus1=50;
        y_bus1=270;
        notice = 1;
    }
    if((x_car1==-335 && x_bus1==158 && l_red==1)||((x_car1<-335 || x_car1 >158) && l_red ==1) ||((x_bus1>158 || x_bus1<-335)&& l_red==1)){

        y_bus1 +=fast;
        if(y_bus1>=900){
            y_bus1=-700;
        }
    }
}


void display(){
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    //Road left
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position,150.0,0.0);
    road(800,-300);
    glPopMatrix();

    //Road right
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position+1100,150.0,0.0);
    road(800,-300);
    glPopMatrix();


    //Road top
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position+800,150.0,0.0);
    road(300,500);
    glPopMatrix();

    //Road bottom
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position+800,-150.0,0.0);
    road(300,-500);
    glPopMatrix();

    //Road center
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position+800,-150.0,0.0);
    road(300,300);
    glPopMatrix();

    //Devider
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position+100,50,0.0);
    devider();
    glPopMatrix();

    //Devider
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(x_position-(x_position)+200,50,0.0);
    devider();
    glPopMatrix();

    //Devider top
    glPushMatrix();
    devider2();
    glPopMatrix();

    //Devider top
    glPushMatrix();
    glTranslatef(0,-700,0.0);
    devider2();
    glPopMatrix();


    // building 1

    glPushMatrix();
    glTranslatef(-400,-120,0.0);
    building1();
    glPopMatrix();


    // building 2

    glPushMatrix();
    glTranslatef(-300,60,0.0);
    building2();
    glPopMatrix();

    // building 3

    glPushMatrix();
    glTranslatef(-550,-110,0.0);
    building1();
    glPopMatrix();



    // building 4

    glPushMatrix();
    glTranslatef(-700,60,0.0);
    building2();
    glPopMatrix();


    // building 5

    glPushMatrix();
    glTranslatef(200,-120,0.0);
    building1();
    glPopMatrix();


    // building 6

    glPushMatrix();
    glTranslatef(400,60,0.0);
    building2();
    glPopMatrix();

    // building 7

    glPushMatrix();
    glTranslatef(550,-110,0.0);
    building1();
    glPopMatrix();



    // building 8

    glPushMatrix();
    glTranslatef(750,60,0.0);
    building2();
    glPopMatrix();




    glPushMatrix();
    glTranslatef(x_car1,80.0,0.0);
    car(0,255,0,0,0,0,0,0,255);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(x_bus1,-80.0,0.0);
    bus(0,12,120,0,60,0,0,255,0);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,y_bus1,0.0);
    bus2();
    glPopMatrix();

    // Traffic light top box
    glPushMatrix();
    glTranslatef(0,250,0.0);
    if(l_red==0){
        traffic(red,0,0,red,green,blue);
    }else{
        traffic(red,green,blue,0,green,0);
    }
    glPopMatrix();

    // Traffic light right box
    glPushMatrix();
    glTranslatef(180,100,0.0);
    if(l_red==0){
        traffic(red,green,blue,0,green,0);
    }else{
        traffic(red,0,0,red,green,blue);
    }
    glPopMatrix();

    // Traffic light bottom box
    glPushMatrix();
    glTranslatef(0,-80,0.0);
    if(l_red==0){
        traffic(red,0,0,red,green,blue);
    }else{
        traffic(red,green,blue,0,green,0);
    }
    glPopMatrix();

    // Traffic light left box
    glPushMatrix();
    glTranslatef(-180,100,0.0);
    if(l_red==0){
        traffic(red,green,blue,0,green,0);
    }else{
        traffic(red,0,0,red,green,blue);
    }
    glPopMatrix();

    glutSwapBuffers();

}

void keyboardFunc( unsigned char key, int x, int y )
{
switch( key )
    {
	case 'l':
	case 'L':
	    // car stop
		l_red=1;
		break;

    case 'g':
	case 'G':
		l_red=0;
		break;
    }
}

int main(int argc, char **argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

    glutInitWindowSize(1300,700);

    glutCreateWindow("Traffic control system");

    glutDisplayFunc(display);   // call back function

    glutKeyboardFunc(keyboardFunc);
    glutTimerFunc(0,timer,0);

    PlaySound(TEXT(sound), NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);

    init();

    glutMainLoop();
}
