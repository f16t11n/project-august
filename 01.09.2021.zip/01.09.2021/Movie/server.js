const path = require('path');
const http = require('http');
const express = require('express');
const socketio = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketio(server);
const formatMessage = require('./util/messages');


//set folder static
app.use(express.static(path.join(__dirname, 'front-end')));

const roomName = 'Movie Gossip room';
// user connection
io.on('connection', socket => {

    //Welcome only user
    socket.emit('message', formatMessage(roomName,'Welcome to gossip galaxy'));
    
    // Welcome message connect
    socket.broadcast.emit("message", formatMessage(roomName,'A user join the room'));
        
        
    // User when left
    socket.on('disconnect', () => {
        io.emit('message',formatMessage(roomName,'A user left group'));
    });
    
    // Message listen;
    socket.on('chatMessage',msg =>{
        io.emit('message',formatMessage('USER',msg));
    });

});

const PORT = 3000 || process.env.PORT;

server.listen(PORT, () => console.log(`Server running on ${PORT}`));