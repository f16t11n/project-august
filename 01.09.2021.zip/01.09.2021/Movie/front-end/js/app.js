const chatForm = document.getElementById('chatForm');
const chatMessages = document.querySelector('.body');

const socket = io();

//Message from server

socket.on('message', message => {
      console.log(message);
      outputMessage(message);

      //scroll down for latest message
      chatMessages.scrollTop = chatMessages.scrollHeight;
});

// message send

chatForm.addEventListener('submit', e => {
      e.preventDefault();

      // Message text
      const msg = e.target.elements.msg.value;

      //Send message to server
      socket.emit('chatMessage', msg);

      //clear input
      e.target.elements.msg.value = "";
      e.target.elements.msg.focus();
});


//Output message to DOM
function outputMessage(message) {
      const div = document.createElement('div');
      if (message.username == "USER") {
            div.classList.add('send-message');
            div.innerHTML = `<div class="message-text d-flex">
      <div class="message">${message.text}</div>
      <div class="time">${message.time}</div>
      </div>`;
      }else{
            div.classList.add("system-msg","text-center" ,"pt-2" ,"fw-bold");
            div.innerHTML =`<p>A user has joined <span class="fw-light" style="font-size:0.8rem; margin-left:10px">${message.time} </span></p>`;
      }
      document.querySelector('.body').appendChild(div);
}

// group box show hide

$(document).ready(function () {

      $("#messenger-icon").click(function () {
            $("#container-mesngr").fadeToggle(1000);
      });
});